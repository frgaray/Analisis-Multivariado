# Tarea 4

## Grupo
- Análisis Multivariado
- Semestre: 2023-1
- Profesora: Ruth Selene Fuentes García
- Facultad de Ciencias, UNAM

## Equipo
Somos el equipo compuesto por:
- Duran Santiago Rafael
- Garay Araujo Fernando Raúl
- Santillán Arriaga Diego Armando

## Archivos 
- En el archivo "Tarea4.pdf" se encuentra la solución a todos los problemas de la tarea.

- En el archivo "tarea4.Rmd" se encuentra el código utilizado para generar la tarea, salvo por el ejercicio 2.

- En el archivo "distanciasMex.csv" se encuentran las distancias de las entidades de la República Mexicana necesitadas para el Ejercicio 1.
