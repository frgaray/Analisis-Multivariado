## Grupo
- Análisis Multivariado
- Semestre: 2023-1
- Profesora: Ruth Selene Fuentes García
- Facultad de Ciencias, UNAM

## Equipo
Somos el equipo compuesto por:
- Duran Santiago Rafael
- Garay Araujo Fernando Raúl
- Santillán Arriaga Diego Armando

## Archivos 
- En el archivo "Tarea3.pdf" se encuentra la solución al ejercicio 1, 2, 3 y 5 de la tarea 3 asignada.

- En el archivo "ejercicios2-4-6" se encuentra la simulación del ejercicio 2 y la solución a los ejercicios 4 y 6 de la tarea 3 asignada.
